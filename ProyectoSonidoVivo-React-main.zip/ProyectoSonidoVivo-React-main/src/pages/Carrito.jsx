import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import carrito from '../data/carrito';

function Carrito(){
    return (
        <>
            <Navbar/>
            <section className="py-5">
                <div className="container">
                    <h2 className="text-center mb-5 fw-bold">Carrito de compras</h2>
                    <div className="row g-4">

                    </div>
                </div>
            </section>
        </>
    );
}